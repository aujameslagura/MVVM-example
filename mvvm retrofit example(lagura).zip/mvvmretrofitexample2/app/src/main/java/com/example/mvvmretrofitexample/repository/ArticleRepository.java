package com.example.mvvmretrofitexample.repository;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.mvvmretrofitexample.response.ArticleResponse;
import com.example.mvvmretrofitexample.retrofit.ApiRequest;
import com.example.mvvmretrofitexample.retrofit.RetrofitRequest;

import okhttp3.Response;

public class ArticleRepository {

}
