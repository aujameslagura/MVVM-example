package com.example.mvvmretrofitexample.response;

public class Article {
}
